﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using taskmanagement.Models;
using System.Linq;

public class TaskRepository : ITaskRepository
{
    private readonly TaskDbContext _context;

    public TaskRepository(TaskDbContext context)
    {
        _context = context;
    }

    public async Task<TaskModel> GetTaskByIdAsync(int id)
    {
        return await _context.Tasks.FindAsync(id);
    }

    public async Task<List<TaskModel>> GetTasksByUserAsync(int userId)
    {
        return await _context.Tasks.Where(t => t.UserId == userId).ToListAsync();
    }

    public async Task<TaskModel> CreateTaskAsync(TaskModel task)
    {
        _context.Tasks.Add(task);
        await _context.SaveChangesAsync();
        return task;
    }

    public async Task<bool> UpdateTaskAsync(TaskModel task)
    {
        var existingTask = await _context.Tasks.FindAsync(task.Id);
        if (existingTask == null) return false;

        existingTask.Title = task.Title;
        existingTask.Description = task.Description;
        existingTask.UserId = task.UserId;
        existingTask.Status = task.Status;

        await _context.SaveChangesAsync();
        return true;
    }
}

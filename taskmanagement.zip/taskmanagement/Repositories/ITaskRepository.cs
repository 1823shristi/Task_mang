﻿using System.Collections.Generic;
using System.Threading.Tasks;
using taskmanagement.Models;

public interface ITaskRepository
{
    Task<TaskModel> GetTaskByIdAsync(int id);
    Task<List<TaskModel>> GetTasksByUserAsync(int userId);
    Task<TaskModel> CreateTaskAsync(TaskModel task);
    Task<bool> UpdateTaskAsync(TaskModel task);
}

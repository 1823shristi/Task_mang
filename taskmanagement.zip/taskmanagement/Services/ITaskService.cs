﻿using taskmanagement.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace taskmanagement.Services
{
    public interface ITaskService
    {
        Task<TaskResponseDto> GetTaskByIdAsync(int id);
        Task<List<TaskResponseDto>> GetTasksByUserAsync(int userId);
        Task<TaskResponseDto> CreateTaskAsync(TaskDto taskDto);
        Task<bool> UpdateTaskAsync(int id, TaskDto taskDto);
    }
}

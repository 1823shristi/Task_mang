﻿using taskmanagement.DTOs;
using taskmanagement.Models;
using Microsoft.EntityFrameworkCore;


public interface ITaskService
{
    Task<TaskResponseDto> GetTaskByIdAsync(int id);
    Task<List<TaskResponseDto>> GetTasksByUserAsync(int userId);
    Task<TaskResponseDto> CreateTaskAsync(TaskDto taskDto);
    Task<bool> UpdateTaskAsync(int id, TaskDto taskDto);
}

public class TaskService : ITaskService
{
    private readonly TaskDbContext _context;

    public TaskService(TaskDbContext context)
    {
        _context = context;
    }

    public async Task<TaskResponseDto> GetTaskByIdAsync(int id)
    {
        var task = await _context.Tasks.FindAsync(id);
        if (task == null) return null;

        return new TaskResponseDto
        {
            Id = task.Id,
            Title = task.Title,
            Description = task.Description,
            Status = task.Status,
            UserId = task.UserId
        };
    }

    public async Task<List<TaskResponseDto>> GetTasksByUserAsync(int userId)
    {
        return await _context.Tasks
            .Where(t => t.UserId == userId)
            .Select(t => new TaskResponseDto
            {
                Id = t.Id,
                Title = t.Title,
                Description = t.Description,
                Status = t.Status,
                UserId = t.UserId
            }).ToListAsync();
    }

    public async Task<TaskResponseDto> CreateTaskAsync(TaskDto taskDto)
    {
        var task = new TaskModel
        {
            Title = taskDto.Title,
            Description = taskDto.Description,
            UserId = taskDto.UserId,
            Status = "Pending" // default status
        };
        _context.Tasks.Add(task);
        await _context.SaveChangesAsync();

        return new TaskResponseDto
        {
            Id = task.Id,
            Title = task.Title,
            Description = task.Description,
            Status = task.Status,
            UserId = task.UserId
        };
    }

    public async Task<bool> UpdateTaskAsync(int id, TaskDto taskDto)
    {
        var task = await _context.Tasks.FindAsync(id);
        if (task == null) return false;

        task.Title = taskDto.Title;
        task.Description = taskDto.Description;
        task.UserId = taskDto.UserId;

        await _context.SaveChangesAsync();
        return true;
    }
}
